
public class tic extends Thread {
	public void run(){
		while (true) {
			System.out.println("tic");
			try {
		        sleep(200);
		    } catch (InterruptedException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		    }
		}	
	}
}


public class tictac {
	public static void main(String[] args) throws InterruptedException {
		Thread tic = new tic();
		Thread tac = new tac();
		tic.start();
		Thread.sleep(100);
		tac.start();
	}
}


public class tac extends Thread{
	public void run(){
		while (true) {
			System.out.println("tac");
			try {
		        sleep(200);
		    } catch (InterruptedException e) {
		        // TODO Auto-generated catch block
		        e.printStackTrace();
		    }
		}	
	}
}
